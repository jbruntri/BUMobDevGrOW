cx,cy = display.contentCenterX,display.contentCenterY
-- requires 

--local physics = require "physics"
--physics.start()

--require "sprite"

--local storyboard = require ("storyboard")
--local scene = storyboard.newScene()

-- background

background = display.newImage("bg.png",cx,cy)
background.width = 1920
background.height = 1080

    city1 = display.newImage("city1.png")
    city1.anchorX = 0
    city1.anchorY = 1
    city1.x = 0
    city1.y = 1080
    city1.speed = 1
    

    city2 = display.newImage("city1.png")
    city2.anchorX = 0
    city2.anchorY = 1
    city2.x = 480
    city2.y = 1080
    city2.speed = 1
    
    city21 = display.newImage("city1.png")
    city21.anchorX = 0
    city21.anchorY = 1
    city21.x = 960
    city21.y = 1080
    city21.speed = 1
    
    city22 = display.newImage("city1.png")
    city22.anchorX = 0
    city22.anchorY = 1
    city22.x = 1440
    city22.y = 1080
    city22.speed = 1

    city23 = display.newImage("city1.png")
    city23.anchorX = 0
    city23.anchorY = 1
    city23.x = 1920
    city23.y = 1080
    city23.speed = 1

    city3 = display.newImage("city2.png")
    city3.anchorX = 0
    city3.anchorY = 1
    city3.x = 0
    city3.y = 1080
    city3.speed = 2
    

    city4 = display.newImage("city2.png")
    city4.anchorX = 0
    city4.anchorY = 1
    city4.x = 480
    city4.y = 1080
    city4.speed = 2

    city41 = display.newImage("city2.png")
    city41.anchorX = 0
    city41.anchorY = 1
    city41.x = 960
    city41.y = 1080
    city41.speed = 2
    
    city42 = display.newImage("city2.png")
    city42.anchorX = 0
    city42.anchorY = 1
    city42.x = 1440
    city42.y = 1080
    city42.speed = 2

    city43 = display.newImage("city2.png")
    city43.anchorX = 0
    city43.anchorY = 1
    city43.x = 1920
    city43.y = 1080
    city43.speed = 2


function scrollCity(self,event)
	if self.x < -477 then
		self.x = 1920
	else 
		self.x = self.x - self.speed
	end
end

--function touchScreen(event)
--    print("touch")
--   if event.phase == "began" then
--   	 jet.enterFrame = activateJets
--   	 Runtime:addEventListener("enterFrame", jet)
--   end
   
--   if event.phase == "ended" then
--   	 Runtime:removeEventListener("enterFrame", jet)
--   end

--end

--function onCollision(event)
--	if event.phase == "began" then
--	  if jet.collided == false then 
--	    jet.collided = true
--	    jet.bodyType = "static"
--	    explode()

--	  end
--	end
--end
	
--	Runtime:addEventListener("touch", touchScreen)

    city1.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city1)

    city2.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city2)

    city21.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city21)

    city22.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city22)

    city23.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city23)

    city3.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city3)

    city4.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city4)
    
    city41.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city41)
    
    city42.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city42)
        
    city43.enterFrame = scrollCity
    Runtime:addEventListener("enterFrame", city43)
    
--   Runtime:addEventListener("collision", onCollision)

--	Runtime:removeEventListener("touch", touchScreen)
--	Runtime:removeEventListener("enterFrame", city1)
--	Runtime:removeEventListener("enterFrame", city2)
--	Runtime:removeEventListener("enterFrame", city3)
--	Runtime:removeEventListener("enterFrame", city4)
--	Runtime:removeEventListener("collision", onCollision)






